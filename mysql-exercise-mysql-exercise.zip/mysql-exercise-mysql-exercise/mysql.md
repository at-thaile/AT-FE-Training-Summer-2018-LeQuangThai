### 1. Tạo Database
* User
```
CREATE TABLE user (
  id            INT(11) NOT NULL AUTO_INCREMENT,
  full_name     VARCHAR(255) NOT NULL,
  email         VARCHAR(255) NOT NULL,
  rank          TINYINT(4) NOT NULL,
  is_active     TINYINT(1),
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
);
```
* Category
```
CREATE TABLE category (
  id            INT(11) NOT NULL AUTO_INCREMENT,
  title         VARCHAR(255) NOT NULL,
  description   VARCHAR(255) NULL,
  PRIMARY KEY (id)
);
```
* News
```
CREATE TABLE news (
  id            INT(11) NOT NULL AUTO_INCREMENT,
  category_id   INT(11) NOT NULL,
  title         VARCHAR(255) NOT NULL,
  view          INT(11) NOT NULL,
  is_active     TINYINT(1),
  content       TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (category_id) REFERENCES category(id)
);
```
* Blog
```
CREATE TABLE blog (
  id            INT(11) NOT NULL AUTO_INCREMENT,
  category_id   INT(11) NOT NULL,
  user_id       INT(11) NOT NULL,
  title         VARCHAR(255) NOT NULL,
  view          INT(11) NOT NULL,
  is_active     TINYINT(1),
  content       TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (category_id) REFERENCES category(id),
  FOREIGN KEY (user_id) REFERENCES user(id)
);
```
* Comment
```
CREATE TABLE comment (
  id            INT(11) NOT NULL AUTO_INCREMENT,
  target_table  VARCHAR(20) NOT NULL,
  target_id     INT(11) NOT NULL,
  user_id       INT(11) NOT NULL,
  comment       TEXT,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (user_id) REFERENCES user(id)
);
```
* Follow
```
CREATE TABLE follow (
  id            INT(11) NOT NULL AUTO_INCREMENT,
  from_user_id  INT(11) NOT NULL,
  to_user_id    INT(11) NOT NULL,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (from_user_id) REFERENCES user(id)
)
```
### 2. Thêm 1 dòng dữ liệu trong bất kỳ table nào
```
INSERT INTO category(title, description)
VALUES ('The Thao', 'Tong hop cac tin tuc ve the thao trong nuoc va quoc te');
```
### 3. Xoá và sửa 1 dòng dữ liệu trong bất kỳ table nào
* Delete
```
DELETE FROM user
WHERE id = 5;
```
* Update
```
UPDATE user
SET full_name = 'Hai Nguyen'
WHERE id = 5;
```
### 4. Select 10 blog mới nhất đã active
```
SELECT * FROM blog
WHERE is_active = 1
ORDER BY created_at DESC
LIMIT 10;
```
### 5. Lấy 5 blog từ blog thứ 10
```
SELECT * FROM blog
WHERE is_active = 1
LIMIT 10, 5;
```
### 6. Set is_active = 0 của user có id = 3 trong bảng user
```
UPDATE user
SET is_active = 0
WHERE id = 3;
```
### 7. Xoá tất cả comment của user = 2 trong blog = 5
```
DELETE FROM comment
WHERE user_id = 2 AND target_table = 'blog' AND target_id = 5;
```
### 8. Lấy 3 blog bất kỳ (random)
```
SELECT * FROM blog
ORDER BY RAND()
LIMIT 3;
```
### 9. Lấy số lượng comment của các blog
```
SELECT COUNT(id) FROM comment
WHERE target_table = 'blog';
```
### 10. Lấy Category có tồn tại blog hoặc news đã active (không được lặp lại category)
```
SELECT DISTINCT category.* FROM category
INNER JOIN blog ON category.id = blog.category_id
INNER JOIN news ON category.id = news.category_id
WHERE news.is_active = 1 AND blog.is_active = 1;
```
### 11. Lấy tổng lượt view của từng category thông qua blog và news
```
SELECT category.title, SUM(blog.view) + SUM(news.view) as TotalView FROM category
INNER JOIN blog ON category.id = blog.category_id
INNER JOIN news ON category.id = news.category_id
GROUP BY category.title
```
### 12. Lấy blog được tạo bởi user mà user này không có bất kỳ comment ở blog
```
SELECT blog.* FROM blog
INNER JOIN user ON blog.user_id = user.id
WHERE user.id NOT IN (SELECT user_id FROM comment WHERE target_table = 'blog')
```
### 13. Lấy 5 blog mới nhất và số lượng comment cho từng blog
```
SELECT blog.id, blog.title, COUNT(comment.id) FROM blog
INNER JOIN comment ON blog.id = comment.target_id
WHERE comment.target_table = 'blog'
GROUP BY blog.id, blog.title
LIMIT 5;
```
### 14. Lấy 3 User comment đầu tiên trong 5 blogs mới nhất
```
SELECT * FROM user
WHERE id IN
(
  SELECT user_id FROM comment
  INNER JOIN
  (
    SELECT id FROM blog ORDER BY created_at DESC LIMIT 5
  ) as newblog
  ON newblog.id = comment.target_id
  WHERE target_table = 'blog'
  ORDER BY created_at DESC
)
LIMIT 3;
```
### 15. Update rank user = 2 khi tổng số lượng comment của user > 20
```
UPDATE user
SET rank = 2
WHERE id IN (SELECT user_id
             FROM comment GROUP BY user_id
             HAVING COUNT(user_id) > 20)
```
### 16. Xoá comment mà nội dung comment có từ "fuck" hoặc "phức"
```
DELETE FROM comment
WHERE comment LIKE '%fuck%' OR comment LIKE '%phức%';
```
### 17. Select 10 blog mới nhất được tạo bởi các user active
```
SELECT * FROM blog
WHERE user_id in (SELECT id FROM user WHERE is_active = 1)
ORDER BY created_at
LIMIT 10;
```
### 18. Lấy số lượng Blog active của user có id là 1,2,4
```
SELECT COUNT(id) FROM blog
WHERE user_id in (1, 2, 4) AND is_active = 1;
```
### 19. Lấy 5 blog và 5 news của 1 category bất kỳ
```
SET @rand_category = (SELECT id FROM category ORDER BY RAND() LIMIT 1);
(SELECT title, content FROM blog
WHERE category_id = @rand_category
LIMIT 5)
UNION
(SELECT title, content FROM news
WHERE category_id = @rand_category
LIMIT 5);
```
### 20. Lấy blog và news có lượt view nhiều nhất
```
(SELECT id, title, content FROM blog ORDER BY view DESC)
UNION
(SELECT id, title, content FROM news ORDER BY view DESC);
```
### 21. Lấy blog được tạo trong 3 ngày gần nhất
```
SELECT * FROM blog
WHERE created_at > DATE_SUB(CURRENT_DATE(), INTERVAL 3 DAY);
```
### 22. Lấy danh sách user đã comment trong 2 blog mới nhất
```
SELECT * FROM user
WHERE id IN
(
  SELECT user_id FROM comment
  INNER JOIN
  (
    SELECT id FROM blog
    ORDER BY created_at DESC
    LIMIT 2
  )as newblog
  ON newblog.id = comment.target_id
  WHERE target_table = 'blog'
);
```
### 23. Lấy 2 blog, 2 news mà user có id = 1 đã comment
```
(SELECT title, content FROM blog
WHERE id in (SELECT target_id FROM comment WHERE target_table ='blog' AND user_id = 1)
LIMIT 2)
UNION
(SELECT title, content FROM news
WHERE id in (SELECT target_id FROM comment WHERE target_table ='news' AND user_id = 1)
LIMIT 2);
```
### 24. Lấy 1 blog và 1 news có số lượng comment nhiều nhất
```
(SELECT title, content FROM blog
INNER JOIN comment ON blog.id = comment.target_id AND comment.target_table = 'blog'
GROUP BY title
ORDER BY COUNT(comment.id)
LIMIT 1)
UNION
(SELECT title, content FROM news
INNER JOIN comment ON news.id = comment.target_id AND comment.target_table = 'news'
GROUP BY title
ORDER BY COUNT(comment.id)
LIMIT 1);
```
### 25. Lấy 5 blog và 5 news mới nhất đã active
```
(SELECT title, content FROM blog
WHERE is_active = 1
ORDER BY created_at DESC
LIMIT 5)
UNION
(SELECT title, content FROM news
WHERE is_active = 1
ORDER BY created_at DESC
LIMIT 5);
```
### 26. Lấy nội dung comment trong blog và news của user id = 1
```
SELECT comment FROM comment
WHERE user_id = 1;
```
### 27. Blog của user đang được user có id = 1 follow
```
SELECT * FROM blog
WHERE user_id IN (SELECT to_user_id FROM follow WHERE from_user_id = 1);
```
### 28. Lấy số lượng user đang follow user = 1
```
SELECT COUNT(from_user_id) FROM follow
WHERE to_user_id = 1
GROUP BY to_user_id;
```
### 29. Lấy số lượng user 1 đang follow
```
SELECT COUNT(to_user_id) FROM follow
WHERE from_user_id = 1
GROUP BY from_user_id;
```
### 30. Lấy 1 comment (id_comment, comment) mới nhất và thông tin của user đang được follow bởi user 1
```
SELECT comment.id, comment.comment, user.full_name FROM comment, user
WHERE comment.user_id IN (SELECT to_user_id FROM follow WHERE from_user_id = 1)
ORDER BY comment.created_at DESC

```
### 31. Hiển thị một chuổi "PHP Team " + ngày giờ hiện tại (Ex: PHP Team 2017-06-21 13:06:37)
```
SELECT CONCAT("PHP TEAM ", CURRENT_TIMESTAMP());
```
### 32. Tìm có tên(user.full_name) "Khiêu" và các thông tin trên blog của user này như: (blog.title, blog.view), title category(category) của blog này.
```
SELECT user.full_name, blog.title, blog.view, category.title FROM user
INNER JOIN blog ON user.id = blog.user_id
INNER JOIN category ON category.id = blog.category_id
WHERE user.fullname = "Khiêu";
```
### 33. Liệt kê email user các user có tên(user.full_name) có chứa ký tự "Khi" theo danh sách như output bên dưới.
```
SELECT GROUP_CONCAT(full_name SEPARATOR ';') AS fullname FROM user
WHERE full_name like "%Khi%";
```
### 34. Tính điểm cho user có email là minh82@example.com trong bảng comment. Cách tính điểm: Trong bảng comment với taget_table = "blog" tính 1 điểm, taget_table = "news" tính 2 điểm.
```
SELECT SUM(IF(target_table = "blog", 1, 2)) AS Diem
FROM comment
INNER JOIN user ON comment.user_id = user.id
WHERE email = "minh82@example.com";
```
