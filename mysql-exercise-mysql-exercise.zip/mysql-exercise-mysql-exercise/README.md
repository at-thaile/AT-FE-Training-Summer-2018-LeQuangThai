mysql exercise
